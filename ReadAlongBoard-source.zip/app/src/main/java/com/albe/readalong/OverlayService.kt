package com.albe.readalong

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** Draws the pad strip on top of other apps, docked to one screen edge. */
class OverlayService : Service() {

    companion object {
        private const val ACTION_STOP = "com.albe.readalong.STOP_STRIP"
        private const val CHANNEL = "strip"
        val isRunning = MutableStateFlow(false)

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }

    private val scope = MainScope()
    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var root: LinearLayout
    private lateinit var tab: TextView
    private lateinit var body: LinearLayout
    private lateinit var catBtn: TextView
    private lateinit var padList: LinearLayout
    private lateinit var stopBtn: TextView
    private val typeBtns = mutableMapOf<PadType, TextView>()
    private val padViews = mutableMapOf<String, Pair<TextView, PadType>>()
    private var added = false

    private var catId: String? = null // null = all categories
    private val types = mutableSetOf<PadType>()
    private var collapsed = false

    private val panelBg = 0xEE171B24.toInt()
    private val ink = 0xFFE9ECF2.toInt()
    private val muted = 0xFF9AA3B4.toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        Repo.init(this)
        SoundEngine.init(this)
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildViews()
        isRunning.value = true
        scope.launch {
            Repo.board.collect {
                applySettings(it.overlay)
                rebuildPads()
            }
        }
        scope.launch { SoundEngine.active.collect { paintActive(it) } }
    }

    override fun onDestroy() {
        scope.cancel()
        SoundEngine.stopAll()
        if (added) runCatching { wm.removeView(root) }
        added = false
        isRunning.value = false
        super.onDestroy()
    }

    // ---------- helpers ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(fill)
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

    private fun label(text: String, sizeSp: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }

    private fun stripHeight(): Int = (resources.displayMetrics.heightPixels * 0.62f).roundToInt()

    // ---------- notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Pad strip", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Pad strip is on")
            .setContentText("Tap to open the board")
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_notif), "Close strip", stopPi
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- views ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun buildViews() {
        val s = Repo.board.value.overlay

        root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        // Collapsed state: a small tab on the edge.
        tab = label("♪", 18f, ink, true).apply {
            background = rounded(panelBg, 12)
            visibility = View.GONE
            setOnClickListener { setCollapsed(false) }
        }
        root.addView(tab, LinearLayout.LayoutParams(dp(30), dp(64)))

        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panelBg, 16)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        root.addView(body, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))

        // Header: drag handle, swap side, collapse.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val handle = label("≡", 18f, muted, true)
        var downY = 0f
        var startY = 0
        handle.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downY = e.rawY; startY = params.y; true }
                MotionEvent.ACTION_MOVE -> {
                    params.y = (startY + (e.rawY - downY)).roundToInt().coerceAtLeast(0)
                    if (added) wm.updateViewLayout(root, params)
                    true
                }
                MotionEvent.ACTION_UP -> { if (abs(e.rawY - downY) < dp(6)) v.performClick(); true }
                else -> false
            }
        }
        val swap = label("⇄", 15f, muted, true).apply {
            setOnClickListener {
                Repo.update { b ->
                    b.copy(overlay = b.overlay.copy(side = if (b.overlay.side == "end") "start" else "end"))
                }
            }
        }
        val hide = label("–", 18f, muted, true).apply { setOnClickListener { setCollapsed(true) } }
        header.addView(handle, LinearLayout.LayoutParams(0, dp(30), 1f))
        header.addView(swap, LinearLayout.LayoutParams(dp(28), dp(30)))
        header.addView(hide, LinearLayout.LayoutParams(dp(28), dp(30)))
        body.addView(header)

        // Category: tap for next, hold for previous.
        catBtn = label("All", 12f, ink, true).apply {
            background = rounded(withAlpha(ink, 0x1A), 8)
            setPadding(dp(4), dp(6), dp(4), dp(6))
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setOnClickListener { cycleCategory(1) }
            setOnLongClickListener { cycleCategory(-1); true }
        }
        body.addView(catBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })

        // Type filters, two per row.
        val rows = PadType.entries.chunked(2)
        rows.forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { t ->
                val b = label(t.short, 10f, t.color.toInt(), true).apply {
                    setPadding(0, dp(4), 0, dp(4))
                    setOnClickListener {
                        if (t in types) types.remove(t) else types.add(t)
                        if (types.size == PadType.entries.size) types.clear()
                        rebuildPads()
                    }
                }
                typeBtns[t] = b
                row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(2); marginEnd = dp(2)
                })
            }
            body.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }

        // Pads.
        padList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(padList)
        }
        body.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(6) })

        stopBtn = label("■ Stop", 12f, ink, true).apply {
            background = rounded(withAlpha(ink, 0x1A), 10)
            setPadding(0, dp(9), 0, dp(9))
            setOnClickListener { SoundEngine.stopAll() }
        }
        body.addView(stopBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })

        params = WindowManager.LayoutParams(
            dp(s.widthDp),
            stripHeight(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (s.side == "start") Gravity.START else Gravity.END)
            y = dp(96)
        }
        root.alpha = s.alpha
        wm.addView(root, params)
        added = true
    }

    private fun setCollapsed(c: Boolean) {
        collapsed = c
        tab.visibility = if (c) View.VISIBLE else View.GONE
        body.visibility = if (c) View.GONE else View.VISIBLE
        applySettings(Repo.board.value.overlay)
    }

    private fun applySettings(s: OverlaySettings) {
        if (!added) return
        root.alpha = s.alpha
        params.gravity = Gravity.TOP or (if (s.side == "start") Gravity.START else Gravity.END)
        if (collapsed) {
            params.width = WindowManager.LayoutParams.WRAP_CONTENT
            params.height = WindowManager.LayoutParams.WRAP_CONTENT
        } else {
            params.width = dp(s.widthDp)
            params.height = stripHeight()
        }
        wm.updateViewLayout(root, params)
    }

    private fun cycleCategory(dir: Int) {
        val cats = Repo.board.value.categories
        val ids: List<String?> = listOf<String?>(null) + cats.map { it.id }
        val i = ids.indexOf(catId).coerceAtLeast(0)
        catId = ids[(i + dir + ids.size) % ids.size]
        rebuildPads()
    }

    private fun rebuildPads() {
        if (!added) return
        val b = Repo.board.value
        if (catId != null && b.categories.none { it.id == catId }) catId = null
        catBtn.text = b.categories.find { it.id == catId }?.name ?: "All"

        typeBtns.forEach { (t, v) ->
            val on = t in types
            v.background = if (on) rounded(withAlpha(t.color.toInt(), 0x40), 8, t.color.toInt())
            else rounded(0x00000000, 8, withAlpha(t.color.toInt(), 0x55))
        }

        val order = b.categories.map { it.id }
        val pads = b.pads
            .filter { (catId == null || it.categoryId == catId) && (types.isEmpty() || it.type in types) }
            .sortedBy { p -> order.indexOf(p.categoryId).let { if (it < 0) Int.MAX_VALUE else it } }

        padList.removeAllViews()
        padViews.clear()
        if (pads.isEmpty()) {
            padList.addView(label("No pads here", 11f, muted).apply { setPadding(0, dp(12), 0, dp(12)) })
        }
        pads.forEach { p ->
            val v = TextView(this).apply {
                text = p.name.ifBlank { "Untitled" }
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER_VERTICAL or Gravity.START
                minHeight = dp(46)
                setPadding(dp(8), dp(6), dp(6), dp(6))
                setOnClickListener { SoundEngine.toggle(p) }
            }
            padViews[p.id] = v to p.type
            padList.addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
        paintActive(SoundEngine.active.value)
    }

    private fun paintActive(active: Set<String>) {
        if (!added) return
        padViews.forEach { (id, pair) ->
            val (v, t) = pair
            val c = t.color.toInt()
            if (id in active) {
                v.background = rounded(c, 10)
                v.setTextColor(0xFF11141B.toInt())
            } else {
                v.background = rounded(withAlpha(c, 0x2E), 10, withAlpha(c, 0x99))
                v.setTextColor(ink)
            }
        }
        val n = active.count { !it.startsWith("preview") }
        stopBtn.text = if (n > 0) "■ Stop ($n)" else "■ Stop"
        tab.text = if (n > 0) "♪$n" else "♪"
    }
}
