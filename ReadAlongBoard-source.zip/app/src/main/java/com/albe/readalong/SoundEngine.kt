package com.albe.readalong

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Plays pads. Each layer of a pad gets its own player, clipped to the layer's crop,
 * and starts after the layer's delay. Must be called on the main thread.
 */
object SoundEngine {
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())

    private class Running(
        val type: PadType,
        val loop: Boolean,
        val players: MutableList<ExoPlayer> = mutableListOf(),
        val starts: MutableList<Runnable> = mutableListOf(),
        val done: MutableSet<ExoPlayer> = mutableSetOf(),
    )

    private val running = mutableMapOf<String, Running>()
    private val _active = MutableStateFlow<Set<String>>(emptySet())
    val active: StateFlow<Set<String>> = _active

    private val attrs = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .build()

    fun init(ctx: Context) {
        app = ctx.applicationContext
    }

    fun toggle(pad: Pad, key: String = pad.id) {
        if (running.containsKey(key)) stop(key) else play(pad, key)
    }

    fun play(pad: Pad, key: String = pad.id) {
        val board = Repo.board.value
        val layers = pad.layers.mapNotNull { l -> board.clips.find { it.id == l.clipId }?.let { l to it } }
        if (layers.isEmpty()) return
        if (pad.type == PadType.MUSIC && board.overlay.musicExclusive && !key.startsWith("preview")) {
            running.filter { it.value.type == PadType.MUSIC }.keys.toList().forEach { stop(it) }
        }
        val r = Running(pad.type, pad.loop)
        running[key] = r
        publish()

        for ((l, clip) in layers) {
            val start = l.startMs.coerceIn(0, (clip.durationMs - 10).coerceAtLeast(0))
            val end = l.endMs?.coerceIn(start + 10, clip.durationMs.coerceAtLeast(start + 10))
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(start)
                .setEndPositionMs(end ?: C.TIME_END_OF_SOURCE)
                .build()
            val item = MediaItem.Builder()
                .setUri(Uri.fromFile(Repo.clipFile(clip)))
                .setClippingConfiguration(clipping)
                .build()
            val p = ExoPlayer.Builder(app).build()
            p.setAudioAttributes(attrs, false) // don't pause other apps' audio
            p.setMediaItem(item)
            p.volume = (pad.volume * l.gain).coerceIn(0f, 1f)
            p.repeatMode = if (pad.loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            p.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_ENDED) layerFinished(key, r, p)
                }

                override fun onPlayerError(error: PlaybackException) {
                    layerFinished(key, r, p)
                }
            })
            p.prepare()
            r.players += p
        }

        // Small headroom so every layer has time to load before the first one is due.
        val t0 = SystemClock.uptimeMillis() + 60
        r.players.forEachIndexed { i, p ->
            val go = Runnable { if (running[key] === r) p.play() }
            r.starts += go
            main.postAtTime(go, t0 + layers[i].first.delayMs.coerceAtLeast(0))
        }
    }

    private fun layerFinished(key: String, r: Running, p: ExoPlayer) {
        if (running[key] !== r) return
        r.done += p
        if (r.done.size >= r.players.size) {
            running.remove(key)
            publish()
            main.post { r.players.forEach { runCatching { it.release() } } }
        }
    }

    fun stop(key: String, fast: Boolean = false) {
        val r = running.remove(key) ?: return
        r.starts.forEach { main.removeCallbacks(it) }
        publish()
        val fadeMs = when {
            fast -> 0L
            r.loop || r.type == PadType.AMB || r.type == PadType.MUSIC -> 700L
            else -> 80L
        }
        fadeAndRelease(r.players.toList(), fadeMs)
    }

    fun stopAll() {
        running.keys.toList().forEach { stop(it) }
    }

    fun stopPreviews() {
        running.keys.filter { it.startsWith("preview") }.forEach { stop(it, fast = true) }
    }

    private fun fadeAndRelease(players: List<ExoPlayer>, ms: Long) {
        if (ms <= 0L) {
            players.forEach { runCatching { it.release() } }
            return
        }
        val startVol = players.map { it.volume }
        val steps = 12
        var i = 0
        val step = object : Runnable {
            override fun run() {
                i++
                val f = (1f - i / steps.toFloat()).coerceAtLeast(0f)
                players.forEachIndexed { k, p -> runCatching { p.volume = startVol[k] * f } }
                if (i >= steps) players.forEach { runCatching { it.release() } }
                else main.postDelayed(this, ms / steps)
            }
        }
        main.post(step)
    }

    private fun publish() {
        _active.value = running.keys.toSet()
    }
}
