@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
)

package com.albe.readalong

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { AppRoot() } }
        if (savedInstanceState == null) handleShared(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShared(intent)
    }

    /** Audio shared or opened from another app becomes pads. */
    private fun handleShared(i: Intent?) {
        if (i == null) return
        val uris = mutableListOf<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> {
                val u: Uri? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableExtra(Intent.EXTRA_STREAM)
                if (u != null) uris += u
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val l: List<Uri>? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                if (l != null) uris += l
            }
            Intent.ACTION_VIEW -> i.data?.let { uris += it }
            else -> return
        }
        if (uris.isEmpty()) {
            i.clipData?.let { cd -> for (k in 0 until cd.itemCount) cd.getItemAt(k).uri?.let { uris += it } }
        }
        setIntent(Intent(this, MainActivity::class.java))
        if (uris.isEmpty()) return
        lifecycleScope.launch {
            val clips = withContext(Dispatchers.IO) { uris.mapNotNull { Repo.importClip(this@MainActivity, it) } }
            Repo.addPadsFor(clips)
            val failed = uris.size - clips.size
            val msg = buildString {
                if (clips.isNotEmpty()) append("Added ${clips.size} pad${if (clips.size == 1) "" else "s"}. ")
                if (failed > 0) append("$failed file${if (failed == 1) "" else "s"} couldn't be read as audio.")
            }
            toast(this@MainActivity, msg.trim())
        }
    }

    override fun onStop() {
        super.onStop()
        SoundEngine.stopPreviews()
    }
}

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

private sealed interface Screen {
    data object Board : Screen
    data class Edit(val padId: String?) : Screen
    data object Categories : Screen
    data object Options : Screen
}

@Composable
private fun AppRoot() {
    var screen by remember { mutableStateOf<Screen>(Screen.Board) }
    BackHandler(enabled = screen != Screen.Board) {
        SoundEngine.stopPreviews()
        screen = Screen.Board
    }
    when (val s = screen) {
        Screen.Board -> BoardScreen(
            onEdit = { screen = Screen.Edit(it) },
            onCategories = { screen = Screen.Categories },
            onOptions = { screen = Screen.Options },
        )
        is Screen.Edit -> EditorScreen(s.padId) { screen = Screen.Board }
        Screen.Categories -> CategoriesScreen { screen = Screen.Board }
        Screen.Options -> OptionsScreen { screen = Screen.Board }
    }
}

// ---------------- Board ----------------

@Composable
private fun BoardScreen(onEdit: (String?) -> Unit, onCategories: () -> Unit, onOptions: () -> Unit) {
    val board by Repo.board.collectAsState()
    val active by SoundEngine.active.collectAsState()
    val stripOn by OverlayService.isRunning.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var cat by remember { mutableStateOf<String?>(null) }
    var types by remember { mutableStateOf(setOf<PadType>()) }
    val catValid = cat?.takeIf { id -> board.categories.any { it.id == id } }

    var canOverlay by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) canOverlay = Settings.canDrawOverlays(ctx)
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        OverlayService.start(ctx)
    }
    fun showStrip() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        else OverlayService.start(ctx)
    }

    // GetContent (not OpenDocument) so the picker also offers file-manager apps.
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val clips = withContext(Dispatchers.IO) { uris.mapNotNull { Repo.importClip(ctx, it) } }
            val failed = uris.size - clips.size
            Repo.addPadsFor(clips, types.singleOrNull(), catValid ?: "")
            val msg = buildString {
                if (clips.isNotEmpty()) append("Added ${clips.size} pad${if (clips.size == 1) "" else "s"}. ")
                if (failed > 0) append("$failed file${if (failed == 1) "" else "s"} couldn't be read as audio.")
            }
            toast(ctx, msg.trim())
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Read-Along Board") },
                actions = {
                    TextButton(onClick = onCategories) { Text("Categories") }
                    IconButton(onClick = onOptions) { Icon(Icons.Default.Settings, contentDescription = "Strip and audio options") }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onEdit(null) },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New pad") },
            )
        },
    ) { inner ->
        Column(Modifier.padding(inner).fillMaxSize()) {
            // Strip control
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Pad strip", style = MaterialTheme.typography.titleSmall)
                        Text(
                            when {
                                !canOverlay -> "Needs permission to show over your reading app"
                                stripOn -> "Showing over other apps"
                                else -> "Off"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    when {
                        !canOverlay -> Button(onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                            )
                        }) { Text("Allow") }
                        stripOn -> OutlinedButton(onClick = { OverlayService.stop(ctx) }) { Text("Hide strip") }
                        else -> Button(onClick = { showStrip() }) { Text("Show strip") }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(onClick = { importer.launch("audio/*") }, modifier = Modifier.weight(1f)) { Text("Import audio") }
                val n = active.count { !it.startsWith("preview") }
                OutlinedButton(onClick = { SoundEngine.stopAll() }, modifier = Modifier.weight(1f), enabled = n > 0) {
                    Text(if (n > 0) "Stop all ($n)" else "Stop all")
                }
            }

            val tabIndex = if (catValid == null) 0 else board.categories.indexOfFirst { it.id == catValid } + 1
            ScrollableTabRow(selectedTabIndex = tabIndex, edgePadding = 12.dp) {
                Tab(selected = catValid == null, onClick = { cat = null }, text = { Text("All") })
                board.categories.forEach { c ->
                    Tab(selected = catValid == c.id, onClick = { cat = c.id }, text = { Text(c.name) })
                }
            }

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                PadType.entries.forEach { t ->
                    FilterChip(
                        selected = t in types,
                        onClick = {
                            val next = if (t in types) types - t else types + t
                            types = if (next.size == PadType.entries.size) emptySet() else next
                        },
                        label = { Text(t.label) },
                        leadingIcon = { Box(Modifier.size(10.dp).padding(0.dp)) { Canvas(Modifier.size(10.dp)) { drawCircle(Color(t.color)) } } },
                    )
                }
            }

            val shown = board.pads.filter { (catValid == null || it.categoryId == catValid) && (types.isEmpty() || it.type in types) }
            if (shown.isEmpty()) {
                Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No pads here yet", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Import audio to turn files into pads, or tap New pad to layer several sounds on one button.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    if (catValid == null) {
                        val groups = board.categories.map { c -> Triple(c.id, c.name, shown.filter { it.categoryId == c.id }) } +
                            Triple("none", "Unsorted", shown.filter { p -> board.categories.none { it.id == p.categoryId } })
                        groups.filter { it.third.isNotEmpty() }.forEach { (id, name, ps) ->
                            item(key = "h-$id", span = { GridItemSpan(maxLineSpan) }) {
                                Text(name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                            }
                            items(ps, key = { it.id }) { p ->
                                PadCard(p, board.clips, p.id in active, { SoundEngine.toggle(p) }, { onEdit(p.id) })
                            }
                        }
                    } else {
                        items(shown, key = { it.id }) { p ->
                            PadCard(p, board.clips, p.id in active, { SoundEngine.toggle(p) }, { onEdit(p.id) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PadCard(p: Pad, clips: List<Clip>, playing: Boolean, onPlay: () -> Unit, onEdit: () -> Unit) {
    val c = Color(p.type.color)
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (playing) c.copy(alpha = 0.28f) else MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(if (playing) 2.dp else 1.dp, if (playing) c else MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth().heightIn(min = 96.dp).combinedClickable(onClick = onPlay, onLongClick = onEdit),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(p.type.short, color = c, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Icon(
                    Icons.Default.Edit, contentDescription = "Edit ${p.name}",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp).clickable(onClick = onEdit),
                )
            }
            Text(p.name.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleSmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
            val n = p.layers.size
            val meta = buildString {
                append(if (n == 1) "1 sound" else "$n sounds")
                if (p.loop) append(" · loops") else append(" · ${secs(p.totalMs(clips))}s")
            }
            Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------------- Pad editor ----------------

@Composable
private fun EditorScreen(padId: String?, onDone: () -> Unit) {
    val board by Repo.board.collectAsState()
    val active by SoundEngine.active.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isNew = remember { padId == null || Repo.board.value.pads.none { it.id == padId } }
    var pad by remember { mutableStateOf(Repo.board.value.pads.find { it.id == padId } ?: Pad()) }
    var importFor by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var newCatOpen by remember { mutableStateOf(false) }
    var catMenu by remember { mutableStateOf(false) }

    fun updateLayer(id: String, f: (Layer) -> Layer) {
        pad = pad.copy(layers = pad.layers.map { if (it.id == id) f(it) else it })
    }

    // Several files at once: the first fills this sound slot, the rest become new sounds on the pad.
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        val target = importFor
        importFor = null
        if (uris.isNotEmpty() && target != null) scope.launch {
            val clips = withContext(Dispatchers.IO) { uris.mapNotNull { Repo.importClip(ctx, it) } }
            val failed = uris.size - clips.size
            if (clips.isNotEmpty()) {
                val first = clips[0]
                val extra = clips.drop(1).map { Layer(clipId = it.id) }
                val idx = pad.layers.indexOfFirst { it.id == target }
                val updated = pad.layers.map { if (it.id == target) it.copy(clipId = first.id, startMs = 0, endMs = null) else it }.toMutableList()
                updated.addAll(if (idx < 0) updated.size else idx + 1, extra)
                pad = pad.copy(layers = updated, name = pad.name.ifBlank { first.name })
            }
            if (failed > 0) toast(ctx, "$failed file${if (failed == 1) "" else "s"} couldn't be read as audio. Try MP3, M4A, OGG or WAV.")
            else if (clips.size > 1) toast(ctx, "Added ${clips.size} sounds")
        }
    }

    fun leave() {
        SoundEngine.stopPreviews()
        onDone()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isNew) "New pad" else "Edit pad") },
                navigationIcon = {
                    IconButton(onClick = { leave() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back without saving") }
                },
                actions = {
                    TextButton(onClick = {
                        val valid = pad.layers.filter { l -> board.clips.any { it.id == l.clipId } }
                        if (valid.isEmpty()) {
                            toast(ctx, "Add at least one sound before saving.")
                        } else {
                            val first = board.clips.first { it.id == valid[0].clipId }
                            val p = pad.copy(layers = valid, name = pad.name.trim().ifBlank { first.name })
                            SoundEngine.stop(p.id, fast = true)
                            Repo.savePad(p)
                            leave()
                        }
                    }) { Text("Save") }
                },
            )
        },
    ) { inner ->
        Column(
            Modifier.padding(inner).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                value = pad.name, onValueChange = { pad = pad.copy(name = it) },
                label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )

            Text("Type", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PadType.entries.forEach { t ->
                    FilterChip(
                        selected = pad.type == t,
                        onClick = { pad = pad.copy(type = t, loop = t == PadType.AMB || t == PadType.MUSIC) },
                        label = { Text(t.label) },
                    )
                }
            }

            Box {
                val catName = board.categories.find { it.id == pad.categoryId }?.name ?: "Unsorted"
                OutlinedButton(onClick = { catMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("Category: $catName") }
                DropdownMenu(expanded = catMenu, onDismissRequest = { catMenu = false }) {
                    DropdownMenuItem(text = { Text("Unsorted") }, onClick = { pad = pad.copy(categoryId = ""); catMenu = false })
                    board.categories.forEach { c ->
                        DropdownMenuItem(text = { Text(c.name) }, onClick = { pad = pad.copy(categoryId = c.id); catMenu = false })
                    }
                    DropdownMenuItem(text = { Text("New category…") }, onClick = { catMenu = false; newCatOpen = true })
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Loop until stopped")
                    Text("Each sound repeats its cropped part", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = pad.loop, onCheckedChange = { pad = pad.copy(loop = it) })
            }

            Text("Pad volume ${(pad.volume * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge)
            Slider(value = pad.volume, onValueChange = { pad = pad.copy(volume = it) }, valueRange = 0f..1f)

            HorizontalDivider()
            Text("Sounds on this pad", style = MaterialTheme.typography.titleMedium)
            Text(
                "Each sound starts after its delay. Drag the crop handles to trim it.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            TimingStrip(pad, board.clips)

            pad.layers.forEachIndexed { i, l ->
                LayerCard(
                    index = i, layer = l, clips = board.clips,
                    playing = "preview-${l.id}" in active,
                    canRemove = pad.layers.size > 1,
                    onChange = { nl -> updateLayer(l.id) { nl } },
                    onImport = { importFor = l.id; importer.launch("audio/*") },
                    onPlay = {
                        SoundEngine.toggle(pad.copy(loop = false, layers = listOf(l.copy(delayMs = 0))), "preview-${l.id}")
                    },
                    onRemove = {
                        SoundEngine.stop("preview-${l.id}", fast = true)
                        pad = pad.copy(layers = pad.layers.filter { it.id != l.id })
                    },
                )
            }
            OutlinedButton(onClick = { pad = pad.copy(layers = pad.layers + Layer()) }, modifier = Modifier.fillMaxWidth()) {
                Text("+ Add another sound")
            }
            Button(onClick = { SoundEngine.toggle(pad, "preview") }, modifier = Modifier.fillMaxWidth()) {
                Text(if ("preview" in active) "Stop preview" else "Preview whole pad")
            }

            if (!isNew) {
                HorizontalDivider()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val copy = pad.copy(id = newId(), name = pad.name + " copy", layers = pad.layers.map { it.copy(id = newId()) })
                        Repo.savePad(copy)
                        toast(ctx, "Duplicated")
                        leave()
                    }, modifier = Modifier.weight(1f)) { Text("Duplicate") }
                    OutlinedButton(
                        onClick = { confirmDelete = true }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    ) { Text("Delete") }
                }
            }
            Spacer(Modifier.height(48.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this pad?") },
            text = { Text("The audio files stay in the app. You can remove unused files in Options.") },
            confirmButton = {
                TextButton(onClick = {
                    SoundEngine.stop(pad.id, fast = true)
                    Repo.update { b -> b.copy(pads = b.pads.filter { it.id != pad.id }) }
                    confirmDelete = false
                    leave()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }

    if (newCatOpen) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newCatOpen = false },
            title = { Text("New category") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name, e.g. Chapter 4") })
            },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = {
                    val c = Category(newId(), name.trim())
                    Repo.update { it.copy(categories = it.categories + c) }
                    pad = pad.copy(categoryId = c.id)
                    newCatOpen = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { newCatOpen = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun TimingStrip(pad: Pad, clips: List<Clip>) {
    val rows = pad.layers.map { l ->
        clips.find { it.id == l.clipId }?.let { c ->
            l.delayMs to ((l.endMs ?: c.durationMs) - l.startMs).coerceAtLeast(10)
        }
    }
    val total = rows.filterNotNull().maxOfOrNull { it.first + it.second } ?: return
    val bar = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            "Timing · ${secs(total)}s" + if (pad.loop) " before looping" else "",
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Canvas(Modifier.fillMaxWidth().height((rows.size * 18).dp)) {
            val h = 12.dp.toPx()
            val r = CornerRadius(4.dp.toPx())
            rows.forEachIndexed { i, row ->
                val y = i * 18.dp.toPx()
                drawRoundRect(track, Offset(0f, y), Size(size.width, h), r)
                if (row != null) {
                    val x = size.width * row.first.toFloat() / total
                    val w = max(3.dp.toPx(), size.width * row.second.toFloat() / total)
                    drawRoundRect(bar, Offset(x, y), Size(w, h), r)
                }
            }
        }
    }
}

@Composable
private fun LayerCard(
    index: Int,
    layer: Layer,
    clips: List<Clip>,
    playing: Boolean,
    canRemove: Boolean,
    onChange: (Layer) -> Unit,
    onImport: () -> Unit,
    onPlay: () -> Unit,
    onRemove: () -> Unit,
) {
    val clip = clips.find { it.id == layer.clipId }
    var menu by remember { mutableStateOf(false) }
    var delayText by remember(layer.id) { mutableStateOf(layer.delayMs.toString()) }

    OutlinedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("#${index + 1}", style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(32.dp))
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(clip?.name ?: "Choose a sound", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Import files…") }, onClick = { menu = false; onImport() })
                        clips.sortedBy { it.name.lowercase() }.forEach { c ->
                            DropdownMenuItem(
                                text = { Text("${c.name} · ${secs(c.durationMs)}s") },
                                onClick = { menu = false; onChange(layer.copy(clipId = c.id, startMs = 0, endMs = null)) },
                            )
                        }
                    }
                }
            }

            if (clip != null) {
                val dur = clip.durationMs.toFloat().coerceAtLeast(20f)
                val start = layer.startMs.toFloat().coerceIn(0f, dur)
                val end = (layer.endMs ?: clip.durationMs).toFloat().coerceIn(start, dur)
                Text("Crop ${secs(start.toLong())}s – ${secs(end.toLong())}s of ${secs(clip.durationMs)}s", style = MaterialTheme.typography.bodySmall)
                RangeSlider(
                    value = start..end,
                    onValueChange = { r ->
                        val s = r.start.toLong()
                        val e = max(r.endInclusive.toLong(), s + 10)
                        onChange(layer.copy(startMs = s, endMs = if (e >= clip.durationMs) null else e))
                    },
                    valueRange = 0f..dur,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = delayText,
                        onValueChange = { v ->
                            delayText = v.filter { it.isDigit() }.take(6)
                            onChange(layer.copy(delayMs = delayText.toLongOrNull() ?: 0))
                        },
                        label = { Text("Delay (ms)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                    Column(Modifier.weight(1f)) {
                        Text("Volume ${(layer.gain * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
                        Slider(value = layer.gain, onValueChange = { onChange(layer.copy(gain = it)) }, valueRange = 0f..1f)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onPlay) { Text(if (playing) "Stop" else "Play this sound") }
                    Spacer(Modifier.weight(1f))
                    if (canRemove) TextButton(onClick = onRemove) { Text("Remove") }
                }
            } else if (canRemove) {
                TextButton(onClick = onRemove) { Text("Remove") }
            }
        }
    }
}

// ---------------- Categories ----------------

@Composable
private fun CategoriesScreen(onBack: () -> Unit) {
    val board by Repo.board.collectAsState()
    var newName by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<Category?>(null) }

    fun move(i: Int, d: Int) = Repo.update { b ->
        val l = b.categories.toMutableList()
        val j = i + d
        if (j in l.indices) Collections.swap(l, i, j)
        b.copy(categories = l)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Categories") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { inner ->
        LazyColumn(
            Modifier.padding(inner).fillMaxSize().imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Text(
                    "This order sets the tabs here and the order of the category tiles on the strip. Deleting a category moves its pads to Unsorted.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            itemsIndexed(board.categories, key = { _, c -> c.id }) { i, c ->
                var text by remember(c.id) { mutableStateOf(c.name) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { v ->
                            text = v
                            if (v.isNotBlank()) Repo.update { b -> b.copy(categories = b.categories.map { if (it.id == c.id) it.copy(name = v.trim()) else it }) }
                        },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { move(i, -1) }, enabled = i > 0) { Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Move up") }
                    IconButton(onClick = { move(i, 1) }, enabled = i < board.categories.size - 1) { Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Move down") }
                    IconButton(onClick = { toDelete = c }) { Icon(Icons.Default.Delete, contentDescription = "Delete ${c.name}") }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newName, onValueChange = { newName = it }, singleLine = true,
                        label = { Text("New category") }, modifier = Modifier.weight(1f),
                    )
                    Button(enabled = newName.isNotBlank(), onClick = {
                        val c = Category(newId(), newName.trim())
                        Repo.update { it.copy(categories = it.categories + c) }
                        newName = ""
                    }) { Text("Add") }
                }
            }
        }
    }

    toDelete?.let { c ->
        val count = board.pads.count { it.categoryId == c.id }
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete “${c.name}”?") },
            text = { Text(if (count == 0) "It has no pads." else "Its $count pad${if (count == 1) "" else "s"} will move to Unsorted.") },
            confirmButton = {
                TextButton(onClick = {
                    Repo.update { b ->
                        b.copy(
                            categories = b.categories.filter { it.id != c.id },
                            pads = b.pads.map { if (it.categoryId == c.id) it.copy(categoryId = "") else it },
                        )
                    }
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } },
        )
    }
}

// ---------------- Options ----------------

@Composable
private fun OptionsScreen(onBack: () -> Unit) {
    val board by Repo.board.collectAsState()
    val s = board.overlay
    fun set(f: (OverlaySettings) -> OverlaySettings) = Repo.update { it.copy(overlay = f(it.overlay)) }
    var width by remember { mutableFloatStateOf(s.widthDp.toFloat()) }
    var alpha by remember { mutableFloatStateOf(s.alpha) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Options") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { inner ->
        Column(
            Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Pad strip", style = MaterialTheme.typography.titleMedium)
            Text("Side of the screen", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = s.side == "start", onClick = { set { it.copy(side = "start") } }, label = { Text("Left") })
                FilterChip(selected = s.side == "end", onClick = { set { it.copy(side = "end") } }, label = { Text("Right") })
            }
            Text("Width ${width.roundToInt()} dp", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = width, onValueChange = { width = it }, valueRange = 72f..200f,
                onValueChangeFinished = { set { it.copy(widthDp = width.roundToInt()) } },
            )
            Text("Opacity ${(alpha * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = alpha, onValueChange = { alpha = it }, valueRange = 0.3f..1f,
                onValueChangeFinished = { set { it.copy(alpha = alpha) } },
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("One music pad at a time")
                    Text("Starting a Music pad fades out the one playing", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = s.musicExclusive, onCheckedChange = { v -> set { it.copy(musicExclusive = v) } })
            }
            Text(
                "On the strip: tap a category to see its pads, and ‹ Back to return. Drag ≡ to move the strip, ⇄ to switch sides, – to tuck it into a small tab. Tapping anywhere outside the strip also tucks it away.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            HorizontalDivider()
            Text("Audio files", style = MaterialTheme.typography.titleMedium)
            if (board.clips.isEmpty()) {
                Text("No audio imported yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            board.clips.sortedBy { it.name.lowercase() }.forEach { c ->
                val uses = board.pads.count { p -> p.layers.any { it.clipId == c.id } }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${secs(c.durationMs)}s · " + if (uses == 0) "not on any pad" else "on $uses pad${if (uses == 1) "" else "s"}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (uses == 0) TextButton(onClick = { Repo.deleteClip(c) }) { Text("Delete") }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}
