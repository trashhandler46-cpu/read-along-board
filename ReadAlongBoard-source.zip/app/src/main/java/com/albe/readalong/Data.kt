package com.albe.readalong

import android.app.Application
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.util.Locale
import java.util.UUID

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Repo.init(this)
        SoundEngine.init(this)
    }
}

fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(12)

fun secs(ms: Long): String = String.format(Locale.US, "%.2f", ms / 1000.0)

@Serializable
enum class PadType(val label: String, val short: String, val color: Long) {
    SFX("SFX", "SFX", 0xFFF2A541),
    VO("VO", "VO", 0xFF3FC7B3),
    AMB("Ambience", "AMB", 0xFF8E9CFF),
    MUSIC("Music", "MUS", 0xFFF27399),
}

@Serializable
data class Category(val id: String, val name: String)

@Serializable
data class Clip(val id: String, val name: String, val file: String, val durationMs: Long)

/** One sound on a pad: which clip, when it starts after the tap, and which part of the clip plays. */
@Serializable
data class Layer(
    val id: String = newId(),
    val clipId: String = "",
    val delayMs: Long = 0,
    val startMs: Long = 0,
    val endMs: Long? = null,
    val gain: Float = 1f,
)

@Serializable
data class Pad(
    val id: String = newId(),
    val name: String = "",
    val type: PadType = PadType.SFX,
    val categoryId: String = "",
    val loop: Boolean = false,
    val volume: Float = 1f,
    val layers: List<Layer> = listOf(Layer()),
)

@Serializable
data class OverlaySettings(
    val side: String = "end",
    val widthDp: Int = 108,
    val alpha: Float = 0.92f,
    val musicExclusive: Boolean = true,
)

@Serializable
data class Board(
    val categories: List<Category> = emptyList(),
    val clips: List<Clip> = emptyList(),
    val pads: List<Pad> = emptyList(),
    val overlay: OverlaySettings = OverlaySettings(),
)

fun Pad.totalMs(clips: List<Clip>): Long = layers.maxOfOrNull { l ->
    val c = clips.find { it.id == l.clipId } ?: return@maxOfOrNull 0L
    l.delayMs + ((l.endMs ?: c.durationMs) - l.startMs).coerceAtLeast(0)
} ?: 0L

/** The board lives in one JSON file; audio is copied into the app's own folder. */
object Repo {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val _board = MutableStateFlow(Board())
    val board: StateFlow<Board> = _board
    private lateinit var file: File
    private lateinit var clipsDir: File
    private var ready = false

    @Synchronized
    fun init(ctx: Context) {
        if (ready) return
        ready = true
        file = File(ctx.filesDir, "board.json")
        clipsDir = File(ctx.filesDir, "clips").apply { mkdirs() }
        if (file.exists()) {
            runCatching { _board.value = json.decodeFromString(Board.serializer(), file.readText()) }
        }
    }

    @Synchronized
    fun update(fn: (Board) -> Board) {
        val b = fn(_board.value)
        _board.value = b
        runCatching {
            val tmp = File(file.parentFile, "board.json.tmp")
            tmp.writeText(json.encodeToString(Board.serializer(), b))
            tmp.renameTo(file)
        }
    }

    fun savePad(p: Pad) = update { b ->
        val i = b.pads.indexOfFirst { it.id == p.id }
        b.copy(pads = if (i >= 0) b.pads.toMutableList().also { it[i] = p } else b.pads + p)
    }

    fun clipFile(c: Clip): File = File(clipsDir, c.file)

    fun deleteClip(c: Clip) {
        runCatching { clipFile(c).delete() }
        update { b -> b.copy(clips = b.clips.filter { it.id != c.id }) }
    }

    /** Copies a picked audio file into the app. Returns null if Android can't read it as audio. */
    fun importClip(ctx: Context, uri: Uri): Clip? {
        var out: File? = null
        return try {
            var name = "Sound"
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { name = it }
            }
            val ext = name.substringAfterLast('.', "").lowercase().takeIf { it.length in 1..5 } ?: "audio"
            val id = newId()
            val fname = "$id.$ext"
            val target = File(clipsDir, fname)
            out = target
            val input = ctx.contentResolver.openInputStream(uri) ?: return null
            input.use { inp -> target.outputStream().use { inp.copyTo(it) } }
            val r = MediaMetadataRetriever()
            val dur = try {
                r.setDataSource(target.absolutePath)
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            } finally {
                runCatching { r.release() }
            }
            if (dur == null || dur <= 0) {
                target.delete()
                return null
            }
            val clip = Clip(id, name.substringBeforeLast('.'), fname, dur)
            update { it.copy(clips = it.clips + clip) }
            clip
        } catch (e: Exception) {
            out?.delete()
            null
        }
    }
}
