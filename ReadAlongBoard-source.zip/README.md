# Read-Along Board

An Android soundboard for reading. You build pads in the app, then show them as a strip over your reading app.

- **Pads** can layer several sounds. Each sound has its own delay, crop and volume.
- **Types**: SFX, VO, Ambience and Music, with filters in the app and on the strip.
- **Categories** set the tab order in the app and the order the strip cycles through.
- **The strip** docks to the left or right edge. Drag ≡ to move it, ⇄ to switch sides, and – to tuck it into a small tab.

## Getting the app

Every push to `main` builds the APK on GitHub. Download `ReadAlongBoard.apk` from the latest release and open it on your phone; Android will ask once to allow installs from your browser or file manager.

New builds install over the old one and keep your pads, because every build is signed with the same key in `app/debug.keystore`.
